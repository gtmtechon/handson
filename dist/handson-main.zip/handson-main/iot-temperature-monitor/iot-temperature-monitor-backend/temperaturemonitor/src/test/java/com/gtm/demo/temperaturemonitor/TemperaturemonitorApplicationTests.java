package com.gtm.demo.temperaturemonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturemonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
