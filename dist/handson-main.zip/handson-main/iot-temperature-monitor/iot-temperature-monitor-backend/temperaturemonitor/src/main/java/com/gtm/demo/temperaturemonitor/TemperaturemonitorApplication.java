package com.gtm.demo.temperaturemonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemperaturemonitorApplication {

	public static void main(String[] args) {
		System.out.println("Application is starting..........");
		SpringApplication.run(TemperaturemonitorApplication.class, args);
	}

}

















