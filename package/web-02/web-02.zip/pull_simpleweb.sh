wget https://raw.githubusercontent.com/gtmtechon/handson/refs/heads/main/handson-web-pub-bas-01/app.js
wget https://raw.githubusercontent.com/gtmtechon/handson/refs/heads/main/handson-web-pub-bas-01/index.html
wget https://raw.githubusercontent.com/gtmtechon/handson/refs/heads/main/handson-web-pub-bas-01/package.json